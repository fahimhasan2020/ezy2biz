<div class="container">
    <div class="row">
        <div class="col-lg-6 mb-2 mb-lg-0">
            <p class="text-center text-lg-left">©2019 Your name goes here.</p>
        </div>
        <div class="col-lg-6">
            <p class="text-center text-lg-right">Template design by
                <a href="#">BizBrainers</a>
            </p>
        </div>
    </div>
</div>